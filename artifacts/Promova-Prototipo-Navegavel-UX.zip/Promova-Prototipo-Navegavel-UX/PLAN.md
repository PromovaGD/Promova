# Promova front-end modernization plan

Planning baseline: 7 September 2026, source commit `93d31ccafce453f45eeaf7bceb09ec13d8bcec24` plus the existing workspace. **No product refactor is implemented by this package.** Wireframes use illustrative local fixtures; they never call the product API.

## Decision and scope

Replace the document-shaped authenticated interface with a persistent shell and route-addressable workspaces. Each route has one primary task. Overview is a concise orientation view, not the old dashboard compressed into cards. Inbox owns evidence triage; Analyses owns saved results and reporting; Framework owns coverage and gaps; Career Plan owns assigned career context; Integrations owns GitHub setup and import. Manager navigation exposes People, Reviews, and Career Configuration. Keep the public landing page as a scrolling narrative using the same brand tokens.

Retain native ES modules and the existing services for this refactor. A framework migration is not necessary to fix these problems and would enlarge the regression surface. Replace whole-root rendering with a persistent shell and independently mounted route workspaces. Use a small explicit route registry, not another condition chain over `state.view`. This is a concrete implementation choice, not a claim that the present renderer is production-ready.

Deliverables: [20-screen audit](AUDIT.md), [interactive wireframes](wireframes.html), [verification record](VERIFICATION.md). The prototype scenario selector is review tooling, outside the proposed product shell. Product labels remain Portuguese; this specification uses English route terminology.

## Evidence and source findings

The archive README, contact sheet, and **every full-page image 01–20 were visually inspected**. Captures are 1440 × 1000 viewports, with full document height. The pending-expanded dashboard reaches 4,348 px; all-level framework 3,769 px; manager configuration 3,129 px. Even two saved analyses produce a 2,966 px dashboard. Height is evidence of composition and density problems, not a blanket prohibition on long data.

| Finding | Behavioral/visual evidence | Required response |
|---|---|---|
| Marketing structure wraps every workspace | `frontend/components/layout.mjs:105` puts header, content and footer in a padded `.section`; `styles.css` ultimately sets section padding to 104 px | Separate PublicLayout, AuthLayout, AppShell; no marketing footer in product |
| Dashboard tabs help, but main tab remains several features | `dashboard-view.mjs:140`, captures 04/05/11/12 | Split inbox, library and reporting; retain bounded previews only on Overview |
| Detail URLs do not identify details | `app.mjs:1627` maps employee detail/result/pending states to dashboard; `evidence-view.mjs` finds results inside loaded arrays | Canonical numeric IDs and direct loaders; never depend on list membership |
| Browser history is replaced on render | `app.mjs:1607`; manager hash update at 1217 also replaces | Push on intentional navigation, replace only normalization/redirect; render has no URL side effect |
| Manager location mixes path and hash | `/manager` plus `#/manager/employees/:id`; selected section/filter is memory-only | One URL parser and one route format; legacy hash adapter |
| Data loads are coupled | `app.mjs:1061` sequentially loads all employee areas; manager selection fetches plan/evidence/analyses together | Route-specific requests, independent failure boundaries and stale-response guards |
| Some accessibility exists | Dashboard arrow-key tabs, escaped content, status messages, 401/403 tests | Preserve these guarantees; add landmarks, focus restoration, dialog behavior and route titles |
| CSS is layered over itself | 3,738-line stylesheet, duplicated root/theme/component rules; `--lavender` and `--radius` are referenced without definitions; body hides horizontal overflow | Extract explicit tokens/layers; fix intrinsic widths instead of clipping body |
| GitHub status is overstated | Panel always says “GitHub conectado” even with empty repository/author in 10 | Status derives from saved settings, test and last sync; no OAuth claim |
| Current plan differs from historical analysis | Maria profile in 10 says L3 → L4; analysis 06 says L4 → L5 | Label analysis values as “Contexto no momento da análise”; never rewrite saved snapshot from current profile |
| Evidence and analysis identifiers differ | `SavedAnalysisResponse.id` is external string; `analysisId` numeric; coverage reference has external `id`, optional numeric `evidenceId` | Typed entity adapters and additive canonical links, never infer one ID from another |
| “Limpar histórico” destroys reviews too | `SavedAnalysisService.clearForUser` deletes review history then saved analyses | Relocate to Analyses overflow with explicit scoped destructive confirmation |

Source inspection includes `index.html`, `app.js`, `promova-config.js`, all of `styles.css`, `frontend/app.mjs`, all three component modules, all six view modules, all eleven service modules, GitHub feature model/panel, all three utilities, config, all nine front-end test files, package scripts, build/dev/dist servers, CI workflow and browser session regression. Targeted backend inspection verifies detail/pagination gaps, current manager scope, immutable analysis transaction, review routes, and deletion effects. No screenshot establishes mobile behavior or hidden error states; those are source findings or proposed states explicitly marked in the audit.

Current automated baseline: `npm test` passes **30/30**. Tests primarily assert HTML strings and mocked HTTP/session behavior. Existing browser E2E covers role landing, employee profile reload/deep-link, backend restart and session expiry, not the proposed routing/viewport behavior. It was inspected, not run in this planning task.

## Information architecture and route contract

Use `/app` for employee features, `/manage` for manager features, and `/workspace` for shared resource details. These browser paths deliberately avoid backend namespaces such as `/analyses` and `/manager`; API base configuration remains explicit. Public and auth routes are excluded from the app shell.

| Audience | Canonical route | Primary task / route state |
|---|---|---|
| Public | `/` with `#product`, `#how-it-works`, `#benefits`, `#integrations` | Understand product and enter authentication |
| Public/auth | `/login?returnTo=…`, `/register?returnTo=…` | One focused form; name only on register; no demo credentials in production |
| Employee | `/app/overview` | Orient to current saved evidence and next triage task |
| Employee | `/app/inbox?status=pending&source=all&from=…&to=…&page=1` | Triage pending; switch to dismissed explicitly; counts scoped to filters |
| Employee | `/app/analyses?from=…&to=…&source=…&page=1` | Browse saved results; distinct capture/analysis/review status labels |
| Employee | `/app/analyses/reports?view=sources\|levels\|trend&from=…&to=…` | One report at a time, retaining all existing distributions/trends |
| Employee | `/app/framework?level=L4&support=all\|missing\|supported&from=…&to=…` | Inspect one level's criterion coverage; missing is the former Criteria screen |
| Employee | `/app/framework/criteria/:criterionId?level=L4&from=…&to=…` | Definition and supporting results; dedicated detail on narrow screens |
| Employee | `/app/career-plan?view=objectives\|context&status=active` | Read assigned objectives or role/levels/characteristics |
| Employee | `/app/integrations` → `/app/integrations/github?view=connection\|sync` | Integration status, saved repository/author, connection test, last sync outcome |
| Employee | `/app/integrations/github/import?pr=7` | Find/select/import a PR as captured evidence; no manual free-text evidence creation |
| Manager | `/manage/people?q=…&role=…&level=…&page=1` | Find a person; no automatic first-person edit |
| Manager | `/manage/people/:employeeId/career-plan?view=objectives\|context` | Selected person's plan workspace; default objectives, context edit explicit |
| Manager | `/manage/people/:employeeId/career-plan/objectives/new` and `/objectives/:objectiveId` | Create or update one objective; full route, desktop editor panel permitted |
| Manager | `/manage/people/:employeeId/evidence?status=…&from=…&to=…&page=1` | Read person's captured evidence |
| Manager | `/manage/people/:employeeId/analyses?review=…&from=…&to=…&page=1` | Read/review person's saved analyses |
| Manager | `/manage/reviews?status=unreviewed\|needs-context\|accepted&employee=…&page=1` | Cross-person review queue; requires new aggregate API |
| Manager | `/manage/career/terminology` | Edit six organization labels with preview |
| Manager | `/manage/career/roles?status=active\|archived&page=1` | Browse role catalog |
| Manager | `/manage/career/roles/new`, `/manage/career/roles/:roleId` | Edit one role and allowed levels; archive via confirmation |
| Manager | `/manage/career/framework?level=L4` | Inspect official ordered levels and criteria, read-only in this scope |
| Both, authorized resource | `/workspace/people/:ownerId/evidence/:evidenceId` | Read source; employee owner alone gets observation/analyze/dismiss |
| Both, authorized resource | `/workspace/people/:ownerId/analyses/:analysisId?view=summary\|source\|history\|review` | Saved immutable snapshot and review history; `review` is manager-only |
| Both | `/account` | Read current identity, role label and sign out; no invented profile/password editing API |
| Both | Existing denied URL renders forbidden workspace; unmatched URL renders not-found | Keep context and safe role-home link; no silent redirection to someone else's record |

The alternatives in query values above are an enum notation, not literal URLs. Use numeric stable resource IDs and validated enum values. Criterion IDs require an additive backend contract; until available use a documented, version-qualified `(frameworkVersion, levelKey, criterionKey)` tuple, not slugified display names. Prefer the additive contract before releasing copyable criterion links.

Employee global navigation: **Visão geral, Caixa de entrada, Análises, Framework, Plano de carreira, Integrações**. Manager: **Pessoas, Revisões, Configuração de carreira**. Configuration section links: Terminologia, Cargos, Framework. Managers have no employee-mode switch today: source roles are mutually exclusive EMPLOYEE/MANAGER; the administrator demo account is a manager, not a third capability tier. Do not invent organization-wide GitHub setup or manager sync controls: the present feature is employee-scoped. A future manager integrations page requires an explicit server capability and operational use case; keep it out of this release.

People directory label may use configured employee terminology with a safe plural fallback; “Pessoas” is the neutral default. Route keys, permission keys and data enums remain stable when labels change.

## Shell and navigation specification

Desktop ≥1200 CSS px: a 216 px persistent sidebar, 56 px top bar, then contextual title/action region (normally 72 px) and section/filter region (normally 48 px). Use auto rows with these as minimums, never clipping wrapped titles. Content fills remaining height and width, with 24 px gutters. At 900–1199 use a 176 px sidebar or user-collapsible drawer; multi-pane views collapse based on actual available width, not device name. Below 900 use the navigation drawer and list-to-detail routing. Minimum supported reflow width is 320 CSS px.

Brand goes to role home inside the product. Top bar identifies the workspace and account; account menu provides identity, role, account view, public-site link and logout. No duplicate “Manager Console” CTA. Breadcrumbs appear on details, e.g. Pessoas / Maria Santos / Análises / Comunicação. On mobile retain the nearest meaningful parent as “Voltar a análises” and a short title; full entity name remains readable in detail. Document title is `Comunicação · Análises · Promova` and updates on navigation.

Page header holds one contextual primary action where applicable: Inbox “Importar PR”; saved analysis “Revisar” for managers, “Próxima pendente” for employee post-analysis context; role catalog “Novo cargo”. Read-only pages need not invent a CTA. Form commit actions belong in a reserved footer within the editor, remaining visible while its body scrolls. Discard/dismiss/delete use secondary or destructive styling, not the primary purple treatment. A review editor may expose both Accept and Request context as deliberate status actions; never add promotion approval semantics.

The shell is a grid with `height:100dvh; grid-template-rows:auto minmax(0,1fr)`. Every flex/grid child between viewport and scroller gets `min-height:0; min-width:0`. Main workspace uses `grid-template-rows:auto auto minmax(0,1fr)`; panels use `auto minmax(0,1fr) auto`. Only panel bodies own `overflow:auto`, with visible scrollbars and `scrollbar-gutter:stable`. The nav may scroll independently if zoom makes its links long. Use named semantic regions and keyboard-accessible scroll containers. No nested vertical scroller inside a text body unless editing a textarea requires it. One body scroller on mobile; list and detail are separate route presentations. At very short heights, 200% text sizing or on-screen keyboard, loosen pinned rows into a single task scroller if necessary. Focus and every control remain reachable; stable layout is a preference, not a content clamp.

| Pattern | Use | Avoid |
|---|---|---|
| Global navigation | Switch independent product areas with real anchors and `aria-current=page` | Buttons masquerading as routes; navigational “Nova evidência” that unpredictably opens first pending |
| Section navigation | Related destinations inside People or Career Configuration; URL-backed links | Same styling as primary save actions |
| Tabs | Alternate facets of the same entity: summary/source/history or plan objectives/context | Independent features such as Integrations as a dashboard tab |
| Filters | Narrow one collection; labeled controls, applied chips, result count; committed state in query | Global date filter silently affecting unrelated future routes |
| Master-detail | Inbox preview and People directory + one selected person's task | People + evidence list + expanded source as three cramped columns |
| Drawer | Mobile global nav; compact filter form; short objective editor if URL-addressable | Long analysis source or multi-step setup trapped in a side drawer |
| Modal | Destructive confirmation and unsaved-changes decision | Main feature navigation or long reading workflows |
| Disclosure | Optional definition/help or one long comment inside a detail workspace | Expanding record after record inside a page-length collection |

When opening source from People, navigate out of the directory to the shared detail workspace, keeping owner breadcrumb and validated return context. Inbox can show a preview at ≥1200; “Abrir evidência” opens the same canonical resource as a full detail route. An optional `selected=<evidenceId>` query controls a preview; a direct detail URL never requires the preview to have been opened. Both entry paths load the same resource and authorization policy.

Mobile drawer: labeled “Menu” button with expanded state, opaque drawer ≤320 px and scrim, native modal dialog behavior, inert background, initial focus, Escape/close control, contained tab sequence and return focus to trigger. Choosing a link closes the drawer and focuses the new route title. On mobile history/source/review use a compact labeled view selector when tabs would overflow. No horizontally hidden primary destinations. These dialog behaviors follow [WAI dialog guidance](https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/).

## Workspaces and data length

| Workspace | Visible first | Long content strategy | Persistent controls |
|---|---|---|---|
| Overview | Current period, saved count, criteria support, source count and one next-task link | At most two latest-analysis rows. One concise empty guidance state; reports behind explicit link | Period selector and Inbox link |
| Inbox | Pending/dismissed filter and records; no analyses/report blocks | Server pagination, default 25; bounded list; preview summary only. Full source route wraps long URLs/text | Filter/count row, pagination, preview open/dismiss |
| Analyses | Result list with source, time, estimate/confidence and review state when available | 25 rows/page, 50 optional; each row opens canonical analysis ID | Filters; pagination; overflow menu containing clear history |
| Reports | One selected distribution or trend with shared period | Bounded report area and accessible textual values; no invented readiness percentage | Sources/Levels/Trend view choice |
| Framework | One selected official level, support filter, criterion list | Bounded list of criteria; dedicated definition/support workspace; supporting analyses paginated once large | Level, support, dates, breadcrumb |
| Analysis detail | Identity/source/date, snapshot L4 and historical L4 → L5 context, current review status | Summary, immutable source+observation, and chronological history are distinct URL-backed facets. Long comments expand inside history; no fixed text truncation in full detail | Parent/back, view choice; manager review entry |
| Evidence detail | Source metadata/status, readable source, clearly separate optional observation | Source body can scroll; observation is a facet on narrow screens. 2,000 char count; retain draft on recoverable error | Analyze/dismiss footer for owner only; source link |
| Career Plan | Current role/current→target and selected objectives or context | Objectives bounded/paged at 25; one edit form. Employee read-only; manager edit context separate from objective creation | View/status controls; save/cancel in editor |
| People | Search, role/level filters, names; selected person header and one facet | Independent directory/active-workspace scrollers; default 25 people; explicit no-selection on base route | Search/filter and selected-person section links |
| Reviews | Person, analysis title, timestamp, current review status | Server queue, 25/page. Review opens dedicated analysis review facet, source/summary easily reachable without losing draft | Queue filters; review editor footer |
| Configuration | One selected section and one entity | Role list paginated; detail form separate; allowed levels list bounded if large; no all-roles edit document | Create/save/cancel/archive in proper context |
| Integrations | Actual configuration status and saved repo/author | Connection, sync and manual import separated. Last sync counts stay local; pending count links to Inbox instead of duplicating list | Save/test/sync in corresponding facet |

Start with semantic paginated lists/tables, not virtualization. This bounds DOM and network work and works with assistive technology. Add virtualization only if measured latency still fails with >200 rendered records, with accessible list positions, focus retention and an equivalent paginated mode. Never fetch all employees and then all their reviews to build Reviews.

No screenshot proves current page-level horizontal overflow: all captures remain 1440 px wide, and body currently hides it. Source shows credible overflow risks (objective form minimum columns and manager hero minimum widths). Replace these with reflow, `minmax(0,1fr)`, wrapping action groups, safe URL breaking and a locally scrollable table only where two-dimensional comparison is indispensable. Do not use `body { overflow-x:hidden }` as the fix. Reflow must preserve content at 320 CSS px; this follows [W3C reflow guidance](https://www.w3.org/WAI/WCAG22/Understanding/reflow.html).

## URL, history, session and authorization rules

1. Parse pathname/query once at startup. Match a route registry with public/auth/employee/manager/resource access metadata. Validate IDs, ranges and enums; malformed IDs give not-found, invalid optional filters normalize predictably. Never start a mutation from a URL.
2. Validate a stored token using `/auth/me` before loading protected resource content. A 503/network failure preserves credentials and offers Retry in a non-sensitive session-validation state. A cached user label is not authorization. Keep token storage changes out of the layout migration; revisit HttpOnly-cookie/CSRF migration as separately scoped backend work.
3. No token: redirect with replace to login and encoded same-origin allowlisted `returnTo`. Preserve the full protected route through login/register switches and refresh. Reject external URLs, protocol-relative URLs, script schemes and non-route payloads. Login success replaces the login entry with the requested permitted route, otherwise the role home. Deliberate visits to `/` remain public even when authenticated; brand inside shell goes to role home.
4. Anchor navigation normally pushes a new history entry. Ctrl/Cmd-click works. Programmatic navigation shares the same router. Canonicalization, legacy redirects, login transitions and post-success evidence→analysis resolution replace. Filter Apply and meaningful view selection push once; live typing remains draft, and optional debounced search uses replace rather than one entry per key. `popstate` restores URL state without pushing/replacing again. [MDN History API guidance](https://developer.mozilla.org/en-US/docs/Web/API/History_API/Working_with_the_History_API) explains these distinct operations.
5. Scope query/cache by authenticated user and resource owner. Dates are local calendar strings transformed once to inclusive UTC instants using the displayed timezone; retain the current local-day behavior initially. Validate from≤to; never show data filtered by undisclosed old dashboard state. Page resets to 1 when filters change. In a future cursor API, use `cursor` instead of pretending a cursor is a page number.
6. IDs and section/view state are in URL. List scroll positions and return focus IDs can be in `history.state`. Preserve full query on a validated return link. On direct entry with no usable history, return to the owner-appropriate list. Do not blindly `history.back()` to an external site. After a record disappears, retain visible detail tombstone or return list with an announced change; never substitute the first employee.
7. Employee access allows only ownerId matching session user; manager access uses the manager API namespace and server-validated employee ownership. Current ManagerController gives managers access to all employee accounts, not a documented team/tenant partition. Preserve that actual scope; do not claim per-team isolation. Multi-organization/team scoping is a separate production contract requirement if deployment needs it.
8. A 401 from an authenticated endpoint clears every user-scoped cache/draft and goes to login with safe return location. Auth form 401 stays an inline credential error. A 403 preserves session and renders forbidden context with a permitted destination; hide actions but enforce on server too. Resource not found/foreign ID must not leak another person's name or record. Keep denials sticky against later async callbacks.
9. Abort obsolete reads with AbortController and a navigation/session epoch check before committing responses. Old person/request results must not overwrite newly selected person or repopulate state after logout. Do not treat aborting a request as proof a mutation was cancelled.
10. Dirty forms preserve in-memory drafts per route/resource. Navigating away opens a concrete Save/Discard/Keep editing decision where saving is supported. Browser unload may use native unsaved warning. Never put source text, comments, tokens or email queries in telemetry. Do not persist sensitive form drafts to localStorage by default.

### Legacy migration

| Old location/state | Replacement |
|---|---|
| `/dashboard`, `?tab=dashboard` | `/app/overview`; visible Inbox and Analyses links replace both stacks |
| `/dashboard?tab=framework` | `/app/framework` |
| `/dashboard?tab=criteria` | `/app/framework?support=missing` |
| `/dashboard?tab=connections` | `/app/integrations/github` (remove intermediate redirect card) |
| `/profile` | `/app/career-plan`; one-time notice links moved GitHub controls to Integrations |
| `/manager` | `/manage/people` |
| `/manager?section=settings` | `/manage/career/roles` with Terminologia section link |
| `#/manager/employees/:id`, including `/manager#/manager/employees/:id` | `/manage/people/:id/career-plan`; parse legacy hash before normalizing path |
| Old in-memory pending/detail/result states | Migrate links/actions in source; there is no durable old record URL to recover |
| `/login` | Retained; register becomes real `/register` |

Read the old stored `promova.auth-route` only as a one-time fallback when no explicit protected destination exists; normalize it, role-check it, scope the new preference by user, and remove obsolete storage after successful migration. Never override a pasted deep link with a remembered route.

## API contracts and domain invariants

These are implementation dependencies, not capabilities demonstrated by the wireframes.

| Contract | Present capability | Required work for proposed production UX |
|---|---|---|
| Auth | Login/register/logout/me and bearer store; public `auth:false` distinction | Retain boundary tests; typed session lifecycle and full returnTo support |
| Evidence | Owner list, owner GET by numeric ID, dismiss, GitHub capture, trusted analyze | Add manager owner-scoped single evidence GET; additive saved `analysisId` link on analyzed records; paged filtered list contract |
| Saved analysis | Owner/employee lists with date filter, numeric analysisId and external string id; reviews separately | Add owner GET `/analyses/:analysisId`, manager GET `/manager/employees/:id/analyses/:analysisId`; return ownerId/evidenceId nullable, immutable snapshot, current review state; list pagination/filtering |
| People | Manager full employee list with query/role/level filtering; plan/detail lists | Add manager single employee summary GET and pagination; direct employee not constrained by current directory results |
| Reviews | Owner read, manager read/append per analysis; UNREVIEWED/ACCEPTED/NEEDS_CONTEXT | Add aggregate `/manager/reviews` with filters/page/counts, stable sort and current-status projection; no client N+1 fanout |
| Framework/insights | Server counts/distributions/current coverage/gaps; criterion references external id + optional evidenceId | Add canonical criterion/version identifiers, analysisId references and paged supports; read-only manager criteria endpoint if current settings expose only levels |
| Career plan | Employee read profile; manager read/update plan and create/update objective | Retain validation; constrain level options to allowed role levels using official order; paged objectives if scale warrants; define version/conflict contract |
| Roles/terminology | Six label keys, create/update/archive role with optional replacementRoleId; archived roles included | List/detail adapter may select from small catalog initially; production pagination/detail if large. Archive preview needs assigned count and valid replacement compatibility or explicit server error |
| GitHub | Per-user settings, save/test/delete/sync, 8 PR search results first page, capture single PR | Expose pagination for search; separate draft/saved config, connection versus sync state; no token input or OAuth flow |

Additive APIs should return a shared page envelope `{items, page, pageSize, total}` using stable server ordering (createdAt descending + numeric ID tie-break; people name + ID). Cap pageSize at 50. Negotiate these contracts before changing existing array endpoints: introduce opt-in pagination/versioning or new endpoints, retain old responses through rollout. Total counts are scoped by filters and authorization. Review list needs current status without one request per item. Canonical analysis lookups must be available before releasing deep links; filtering a full list is only a temporary development adapter, not the production solution.

Preserve evidence immutability: POST `/evidences/:id/analysis` sends only `{userObservation}`; backend owns source/profile/framework and saves the result with status transition in one transaction. No browser-generated classification, editable source, new profile override or external-ID routing. Already analyzed evidence returns existing result under the current transaction logic; dismissed evidence conflicts. After ambiguous network failure, reload evidence/result and offer safe retry; never claim background job persistence or cancel support that does not exist.

Review history is append-only while an analysis exists. Accept and Request context record events, optionally commented up to 2,000 chars; no edit/delete event UI. Preserve existing optional-comment semantics. Employee review history is read-only; **there is no employee reply endpoint**. For NEEDS_CONTEXT, offer view source/manager discussion guidance, not a fake response composer or mutation of old observation. The future review-write contract should support idempotency keys and expected latest event/version; absent that, disable repeat submit and reconcile via GET after ambiguous failure, rather than automatically reposting.

Clear history is an existing destructive employee operation. Keep in Analyses “Mais ações”, not filters or Framework. Confirmation states affected period, count and that saved analyses plus reviews are removed, while captured evidence is a separate resource. Current code leaves captured records after deleting analyses; reconcile analyzed-without-result into an explicit unavailable-result state. No invented undo/reanalysis. Confirm intended retention and reanalysis policy before changing the backend behavior; until then preserve it and describe it accurately.

Archive role selects active compatible replacement when required by assigned users. Server remains authoritative; show validation in the form and preserve input. Archived roles become read-only and cannot be newly assigned; historical labels/context remain readable. Never hardcode L1–L5 order: use framework data. Unknown confidence/status displays “Não informado”, not the current helper's fallback to medium confidence. Do not equate no matching criterion evidence with negative performance, an impact estimate with the person's current level, or an accepted analysis with a promotion decision.

## Proposed module boundaries and implementation sequence

| Package / file responsibility | Extraction from current source |
|---|---|
| `frontend/router/{routes,match,navigate,legacy,guards}.mjs` | routeForState, browserRoute, restoreAuthenticatedLocation, manager hash logic |
| `frontend/shell/{app-shell,public-layout,auth-layout,sidebar,drawer,page-header}.mjs` | layout.mjs split; keep brand assets/icons |
| `frontend/state/{session,route-data,drafts}.mjs` | app.mjs singleton decomposed; session epoch, cache keys, independent status |
| `frontend/features/{overview,inbox,analyses,framework,career,people,reviews,career-settings}` | dashboard/profile/manager/evidence view fragments and action handlers |
| `frontend/features/github-import` | Retain model/service contracts; split connection/sync/import views; remove duplicate pending list |
| `frontend/components/{collection,empty-state,error-state,form-field,status-badge,confirm-dialog}.mjs` | Consistent non-domain primitives; escaped values and focus semantics |
| `frontend/services/{existing modules,resource-detail-api,review-queue-api}.mjs` | Existing HTTP facade + new adapters, typed error metadata, cancellation support |
| `frontend/styles/{tokens,base,shell,components,features,public}.css` | Replace duplicate cascade deliberately; `styles.css` remains entry import during transition |
| Tests + scripts | Route/contract tests, browser navigation/viewport fixtures, static asset fallback checks |

Mount AppShell once per authenticated session. A workspace owns its event bindings, loading states, focus target and teardown; renderer returns a mount/update/dispose contract. Avoid unescaped `innerHTML`; reuse `escapeHtml` for template text and validate URLs before assigning href. Framework detail and source text are untrusted data. Navigate via links, mutate via forms/buttons. Replace DOM only inside the component that changed; review text and focus must survive history refresh or sibling data loading.

| Phase / owner | Concrete delivery | Dependencies and acceptance |
|---|---|---|
| P0 — FE + API, 2–3 engineer-days | Freeze fixtures/screens, entity ID map and additive API schemas; write route cases; confirm deletion/role semantics | No visual changes; verify every captured feature has destination. Contract gaps above assigned to backend tickets |
| P1 — FE, 3–4 days | Tokens, separate public/auth layouts, persistent shell, route registry, legacy adapters, session/permission states | Direct nested routes load assets, refresh/back/forward work, mobile drawer keyboard flow passes |
| P2 — API, 4–7 days | Canonical detail, page envelopes, employee summary, review queue and criterion IDs/links | Owner/manager resource tests, stable pagination, independent of list filters; needed before P3 detail/Reviews release |
| P3 — FE, 4–6 days | Overview, Inbox, Analyses, detail/history/review facets, Reports, Framework coverage/gaps | Old task flows retain all fields/actions; no in-memory-only detail routes; long fixtures stay bounded |
| P4 — FE, 3–5 days | Career plan + People + objective editors + queue + career configuration + GitHub split | Owner read-only and manager mutations verified; forms retain drafts/errors; archive replacement flow tested |
| P5 — FE/QA/API, 3–5 days | Accessibility, browser/device coverage, failure/concurrency testing, measured rollout | All release gates below; no critical permission, data-loss, routing or inaccessible-action defect |

Estimate: **19–30 engineer-days across FE/API/QA**, not a committed calendar schedule. Re-estimate after P0 contracts; frontend and API can progress with agreed fixtures independently. No framework upgrade, provider expansion, notification system, promotion engine, password reset or full framework authoring is included.

Roll out additive backend contracts first. Use a session-stable shell flag with parity for both roles. During pilot old routes remain redirectable and a support rollback can select the old layout without deleting user data or reverting additive APIs. Do not run old and new routers simultaneously. Compare failed route loads, detail-not-found, API failures and mutation duplicates by route ID/status without evidence text. Remove legacy rendering only after role workflows and redirect tests pass, preserving external old links for one documented deprecation window.

## Release gates

- Desktop at 1440×1000 and 1280×720: navigation/title and task commit controls stay visible while 500-record fixtures scroll only in declared regions. Expanding long text never grows the entire page into unrelated features. Body horizontal overflow is zero without hiding it.
- Mobile at 390×844 and 320×740, tablet 768×1024, landscape/short height, 200% text and 400% browser zoom: one task remains usable; menu contains all role destinations; no inaccessible clipped action/footer. Keyboard can reach and scroll all bounded content. Test Chrome, Firefox and Safari, plus mobile Safari/Chrome.
- URL tests cover every route from cold load and logged-out returnTo, parent link, reload, browser back/forward, invalid ID, deleted ID, filter changes, legacy paths/hash, forbidden role, direct same-owner/foreign-owner resource access. New tab opening uses native links. Bad assets return 404, not HTML masquerading as JavaScript; SPA fallback applies to intended routes only.
- Keyboard tests: skip link to main, visible focus, modal focus containment/return, Escape, route-heading focus, tabs Home/End/arrow keys when used, no pointer-only row actions. Use semantic tables/lists; announce loading completion, error and result counts without rereading entire source.
- Visual language: preserve purple #4b1fd1 and navy #111744 with quieter white/pale neutral surfaces; 4/8 px spacing scale, 8–12 px radii, limited shadows, 14–16 px body text, 24–28 px desktop title. Tokens for every state; contrast checked per actual pair; target WCAG 2.2 AA. State is always text+color, no gratuitous card lift or pulsing motion. Respect reduced motion across the whole interface.
- Mutations: double click, disconnect/retry, uncertain response, session expiry in flight, changing selected person during read/write, stale version, archived role, missing profile/framework and 2,000-char boundaries. Success is based on server acknowledgement, with scope-appropriate invalidation; failure preserves editable values. Request-context acceptance status/history stays consistent between employee and manager.
- Content correctness: distinguish saved historical profile from live plan; criterion gap is not a negative assessment; source observations remain separate; all six custom labels and long translations wrap; official levels/allowed roles drive options. Prototype-only providers and demo accounts are absent from production auth. Landing integration claims match available GitHub capture, while legacy Slack/Jira records remain readable.
- Performance: one initial shell/session bootstrap, only active-route data. Target usable cached navigation under 200 ms and cold primary workspace under 2 s on a declared representative test profile, excluding analysis engine runtime. Record API/paint durations separately; do not make artificial progress estimates. Test list request size and DOM size, not just a visually bounded full-array fetch.
- Existing `npm run check`, expanded browser regression and backend authorization/contract tests pass in CI. Current string assertions that encode obsolete dashboard tabs are replaced with behavioral route coverage, not simply deleted. Capture all replacement scenarios with the same deterministic technique as the archive.

## Remaining contract decisions with safe defaults

The UI layout is ready to implement after P0; unresolved backend behavior is not hidden by mock controls. API owner must define criterion/version IDs, queue sort/filter schema, conflict/idempotency strategy and archive impact metadata. Default to existing employee/manager authority and optional review comments. Keep current registration policy until product/auth owner explicitly changes it. If multi-tenant deployment is required, scoped manager authorization is a launch prerequisite; the present code does not establish it. Employee responses to requests for context and GitHub organization administration are future features, not implied by these screens.
